import { Component, OnInit } from '@angular/core';
import { TravelService } from '../Services/travel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-package',
  templateUrl: './add-package.component.html',
  styleUrls: ['./add-package.component.css']
})
export class AddPackageComponent implements OnInit {

  status:any;
  errorMsg:any;
  tour = "Domestic";
 
  constructor(private _travelService:TravelService, private router : Router) { }

  ngOnInit() {

    this.status = sessionStorage.getItem("logon");
    console.log(this.status);
    if (this.status == null || this.status == "logout") {
      
      console.log("gjhb");
      this.router.navigate(['/']);
    }
  }


  addPackageForm(form){
    console.log(form.value);
    this._travelService.addPackage(form).subscribe(
      responseAddStatus => {
        console.log("King"+responseAddStatus);
        if(responseAddStatus=="1"){
          this.status= "Successfully added the package";
        }
        else{
          this.status="invalid";
        }
        
       
      },
      responseLoginError => {
        
        this.errorMsg = responseLoginError;
      },
      
    )
  }



}
