import { Component, OnInit } from '@angular/core';
import { TravelService } from '../Services/travel.service';
import { Router } from '@angular/router';
import { concat } from 'rxjs';

@Component({
  selector: 'app-common-layout',
  templateUrl: './common-layout.component.html',
  styleUrls: ['./common-layout.component.css']
})
export class CommonLayoutComponent implements OnInit {

  User: String ="Admin";
  constructor(private _travelService:TravelService, private router : Router) { }

  ngOnInit() {

  }

  
  logout() {
    
    sessionStorage.removeItem("logon");
    sessionStorage.setItem("logon", "logout");
    this.router.navigate(['/addPackage']);
  }
}
