export class Package {
    packageId:number;
    packageName:String;
    packageCategory:String;
    packageDescription:String;
    tourType:String;

}