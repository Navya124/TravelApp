export class Login {
    EmailId : String;
    Password: string;
}