import { Component, OnInit } from '@angular/core';
import { TravelService } from '../Services/travel.service';
import { NgForm } from '@angular/forms';

import { Router } from '@angular/router';
import { CommonLayoutComponent } from '../common-layout/common-layout.component';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  constructor(private _travelService: TravelService, private router: Router) { }
  showDiv: boolean = false;
  status:String;
  msg:any;
  errorMsg:any;
  submitLoginForm(form: NgForm) {


    this._travelService.validateCredentials(form.value.email, form.value.password).subscribe(
      (responseLoginStatus: boolean) => {
        this.showDiv = true;
        if (responseLoginStatus) {

          sessionStorage.setItem("logon", "admin");
          this.router.navigate(['/addPackage']);
        }
        if(!responseLoginStatus) {
          this.msg = this.status + ". Try again with valid credentials.";
        }
      },
      responseLoginError => {
        
        this.errorMsg = responseLoginError;
      },
      () => console.log("SubmitLoginForm method executed successfully")
    );
   
  }

  ngOnInit() {
  }

}
