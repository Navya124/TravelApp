import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AddPackageComponent } from './add-package/add-package.component';
import { CommonLayoutComponent } from './common-layout/common-layout.component';



const routes: Routes = [
  { path: '', component: AdminLoginComponent },
  { path: 'addPackage', component: AddPackageComponent },
  { path: 'common', component: CommonLayoutComponent }
];


export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
