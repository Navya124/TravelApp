import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { routing } from './app.routing';



import { AppComponent } from './app.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AddPackageComponent } from './add-package/add-package.component';
import { TravelService } from './Services/travel.service';
import { CommonLayoutComponent } from './common-layout/common-layout.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    AddPackageComponent,
    CommonLayoutComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    routing, CommonModule
  ],
  providers: [TravelService],
  bootstrap: [AppComponent]
})
export class AppModule { }
