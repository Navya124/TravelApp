import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Login } from '../Interfaces/Login';
import { catchError, tap } from 'rxjs/operators';
import { Package } from '../Interfaces/Package';

@Injectable({
  providedIn: 'root'
})
export class TravelService {

  status:boolean = false;

  constructor(private http: HttpClient) { }

  validateCredentials(email: string, password: string): Observable<any> {
    var userObj: Login;
    userObj = { EmailId: email, Password: password};
    console.log(userObj)
    return this.http.post<any>('https://localhost:44387/api/Admin/ValidateAdmin', userObj).pipe(catchError(this.errorHandler));
    
   
  }

  addPackage(form): Observable<string>{
    console.log("Hlooo"+form);
    var userObj:Package;
    userObj={packageId:form.value.packageId,packageName:form.value.packageName,packageCategory:form.value.packageCategory,packageDescription:form.value.packageDescription,tourType:form.value.tourType};
    console.log(userObj);
    return this.http.post<string>('https://localhost:44387/api/Admin/AddPackage', userObj).pipe(catchError(this.errorHandler)); 
  }

  loginStatus(status):boolean{
    
    if(status==1){
      this.status=true;
    }
    if(status=2){
      this.status=false;
    }
 return this.status;
  }
  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }


}
